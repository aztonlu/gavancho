<?php

//Incluyo el archivo de sesion para impedir el acceso no autorizado a esta página.
require('sesion.php');

//header("Location: ../galeria_de_fotos/admin.php");
header("Location: ../indexcalendario.php");

?>
